import { useState, useRef } from 'react';
import { useTranslation } from '../hooks/useTranslation';

interface TranslationSectionProps {
  onTranslationComplete?: (result: string) => void;
}

export default function TranslationSection({ onTranslationComplete }: TranslationSectionProps) {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [selectedLang, setSelectedLang] = useState('en');
  const [translatedBlob, setTranslatedBlob] = useState<Blob | null>(null);
  const [translatedFilename, setTranslatedFilename] = useState<string>('');
  const [originalText, setOriginalText] = useState<string>('');
  const [translatedText, setTranslatedText] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const { translateFile, isTranslating, error } = useTranslation();

  const handleFileSelect = (file: File) => {
    if (file.size > 5 * 1024 * 1024) {
      alert('File too large. Maximum size is 5MB');
      return;
    }
    const ext = file.name.split('.').pop()?.toLowerCase();
    if (!['txt', 'pdf', 'docx'].includes(ext || '')) {
      alert('File type not supported. Please use .txt, .pdf, or .docx');
      return;
    }
    setSelectedFile(file);
    
    if (ext === 'txt') {
      const reader = new FileReader();
      reader.onload = (e) => setOriginalText(e.target?.result as string);
      reader.readAsText(file);
    } else {
      setOriginalText('');
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (file) handleFileSelect(file);
  };

  const handleTranslate = async () => {
    if (!selectedFile) return;
    try {
      const result = await translateFile(selectedFile, selectedLang);
      setTranslatedBlob(result.blob);
      setTranslatedFilename(result.filename);
      
      const ext = selectedFile.name.split('.').pop()?.toLowerCase();
      if (ext === 'txt') {
        const text = await result.blob.text();
        setTranslatedText(text);
      }
      onTranslationComplete?.(result.filename);
    } catch (err) {
      // Error handled by hook
    }
  };

  const handleDownload = () => {
    if (translatedBlob && translatedFilename) {
      const url = URL.createObjectURL(translatedBlob);
      const a = document.createElement('a');
      a.href = url;
      a.download = translatedFilename;
      document.body.appendChild(a);
      a.click();
      URL.revokeObjectURL(url);
      document.body.removeChild(a);
    }
  };

  const handleReset = () => {
    setSelectedFile(null);
    setTranslatedBlob(null);
    setTranslatedText(null);
    setTranslatedFilename('');
    setOriginalText('');
  };

  return (
    <div className="translation-section">
      {!translatedBlob && (
        <>
          <div 
            className="drop-zone"
            onDrop={handleDrop}
            onDragOver={(e) => e.preventDefault()}
            onClick={() => fileInputRef.current?.click()}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept=".txt,.pdf,.docx"
              hidden
              onChange={(e) => e.target.files?.[0] && handleFileSelect(e.target.files[0])}
            />
            <div>{selectedFile ? selectedFile.name : 'Drop file or click to select'}</div>
          </div>

          <select value={selectedLang} onChange={(e) => setSelectedLang(e.target.value)}>
            <option value="en">English</option>
            <option value="fr">Français</option>
            <option value="es">Español</option>
            <option value="de">Deutsch</option>
          </select>

          <button onClick={handleTranslate} disabled={!selectedFile || isTranslating}>
            {isTranslating ? 'Translating...' : 'Translate'}
          </button>
        </>
      )}

      {error && <div className="error">{error}</div>}
      
      {translatedBlob && (
        <div className="preview-section">
          <div className="preview-header">
            <h3>Preview - Original vs Translation</h3>
            <div>
              <button onClick={handleDownload} className="download-btn">
                Download Translation
              </button>
              <button onClick={handleReset} className="reset-btn">
                New Translation
              </button>
            </div>
          </div>
          
          <div className="preview-container">
            <div className="preview-panel">
              <h4>Original</h4>
              <pre className="preview-content">
                {originalText || 'Binary file - preview not available'}
              </pre>
            </div>
            <div className="preview-panel">
              <h4>Translation</h4>
              <pre className="preview-content">
                {translatedText || 'Binary file - preview not available'}
              </pre>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
