import { useState, useEffect, useRef } from 'react';
import { useTranslation as useI18n } from 'react-i18next';
import { useTranslation } from '../hooks/useTranslation';
import { motion, useScroll, useTransform } from 'motion/react';
const logo = "/Logo.png";
const mascot = "/Identite Precis.png";


export default function Home() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isAnnual, setIsAnnual] = useState(true);
  const { t, i18n } = useI18n();
  const [activeSection, setActiveSection] = useState('hero');
  const [showPreview, setShowPreview] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [numPages, setNumPages] = useState(1);
  const [zoom, setZoom] = useState(1.0);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [targetLang, setTargetLang] = useState('en');
  const [translatedBlob, setTranslatedBlob] = useState<Blob | null>(null);
  const [translatedFilename, setTranslatedFilename] = useState<string>('');
  const [isTrialMode, setIsTrialMode] = useState(true);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { translateFile, isTranslating, error: translateError } = useTranslation();

  const heroRef = useRef<HTMLElement>(null);
  const storyRef = useRef<HTMLElement>(null);
  const aboutRef = useRef<HTMLElement>(null);

  const { scrollYProgress: heroScrollProgress } = useScroll({
    target: heroRef,
    offset: ["start start", "end start"]
  });
  const heroBgY = useTransform(heroScrollProgress, [0, 1], [0, 120]);
  const heroGridY = useTransform(heroScrollProgress, [0, 1], [0, 80]);

  const { scrollYProgress: storyScrollProgress } = useScroll({
    target: storyRef,
    offset: ["start end", "end start"]
  });
  const storyVisualY = useTransform(storyScrollProgress, [0, 1], [40, -40]);

  const { scrollYProgress: aboutScrollProgress } = useScroll({
    target: aboutRef,
    offset: ["start end", "end start"]
  });
  const aboutVisualY = useTransform(aboutScrollProgress, [0, 1], [40, -40]);

  useEffect(() => {
    const sections = document.querySelectorAll('section');

    const observerOptions = {
      root: null,
      rootMargin: '-50% 0px',
      threshold: 0
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          setActiveSection(entry.target.id);
        }
      });
    }, observerOptions);

    sections.forEach((section) => observer.observe(section));

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const htmlEl = document.documentElement;
    if (showPreview) {
      htmlEl.classList.add('preview-active');
    } else {
      htmlEl.classList.remove('preview-active');
    }
    return () => {
      htmlEl.classList.remove('preview-active');
    };
  }, [showPreview]);

  useEffect(() => {
    let active = true;
    let originalUrl: string | null = null;
    let translatedUrl: string | null = null;
    const renderTasks: any[] = [];

    const loadPDFs = async () => {
      const pdfjsLib = (window as any).pdfjsLib;
      if (!pdfjsLib) {
        console.error('PDF.js not loaded');
        return;
      }

      pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.16.105/pdf.worker.min.js';

      try {
        // Use translated blob if available, otherwise fallback to demo files
        let pdfSourceOrig: any;
        let pdfSourceTrad: any;
        
        if (translatedBlob && selectedFile) {
          // Create object URL from translated blob
          translatedUrl = URL.createObjectURL(translatedBlob);
          originalUrl = URL.createObjectURL(selectedFile);
          pdfSourceOrig = pdfjsLib.getDocument(originalUrl);
          pdfSourceTrad = pdfjsLib.getDocument(translatedUrl);
        } else {
          // Fallback to demo files
          pdfSourceOrig = pdfjsLib.getDocument('/CV_Mbowou_Ibrahim_Pigier.pdf');
          pdfSourceTrad = pdfjsLib.getDocument('/CV_Mbowou_Ibrahim_Pigier_TRADUIT.pdf');
        }
        
        const pdfOrig = await pdfSourceOrig.promise;
        if (!active) return;
        setNumPages(pdfOrig.numPages);

        const pdfTrad = await pdfSourceTrad.promise;
        if (!active) return;

        const renderPage = async (pdf: any, canvasId: string, pageNum: number) => {
          const page = await pdf.getPage(pageNum);
          if (!active) return;
          const canvas = document.getElementById(canvasId) as HTMLCanvasElement;
          if (!canvas) return;
          const containerWidth = canvas.parentElement?.clientWidth || 600;
          const unscaledViewport = page.getViewport({ scale: 1.0 });
          const baseScale = containerWidth / unscaledViewport.width;
          const scale = baseScale * zoom;
          const viewport = page.getViewport({ scale });
          const context = canvas.getContext('2d');
          if (!context) return;
          canvas.height = viewport.height;
          canvas.width = viewport.width;

          const renderContext = {
            canvasContext: context,
            viewport: viewport
          };
          const renderTask = page.render(renderContext);
          renderTasks.push(renderTask);
          await renderTask.promise;
        };

        // Render Hero canvases (only with demo files)
        if (!translatedBlob && !selectedFile) {
          await renderPage(pdfOrig, 'pdf-canvas-hero-source', 1);
          await renderPage(pdfTrad, 'pdf-canvas-hero-translated', 1);
        }

        // Render Preview canvases
        await renderPage(pdfOrig, 'pdf-canvas-original', currentPage);
        await renderPage(pdfTrad, 'pdf-canvas-translated', currentPage);

      } catch (error) {
        if (error instanceof Error && error.name === 'RenderingCancelledException') {
          return;
        }
        console.error('Error loading PDF:', error);
      }
    };

    loadPDFs();

    // Sync scroll between both canvases via the shared .scroll container
    const scrollEl = document.getElementById('scroll');
    if (scrollEl) {
      (scrollEl as any)._syncHandlerSet = true;
    }

    return () => {
      active = false;
      // Clean up object URLs
      if (originalUrl) URL.revokeObjectURL(originalUrl);
      if (translatedUrl) URL.revokeObjectURL(translatedUrl);
      renderTasks.forEach(task => {
        try {
          task.cancel();
        } catch (e) {
          // ignore
        }
      });
    };
  }, [showPreview, currentPage, zoom, translatedBlob, selectedFile]);

  return (
    <div className="min-h-screen bg-white text-gray-900 font-body">
      {/* ============================
           NAVBAR
           ============================ */}
      <nav className="navbar" id="navbar">
        <div className="nav-inner">
          <a href="#hero" className="nav-logo" style={{ display: 'flex', alignItems: 'center' }}>
            <img src={logo} alt="P" className="h-[46px] w-auto" />
            <span className="animated-logo-text">
              <span style={{ animationDelay: '0.0s' }}>r</span>
              <span style={{ animationDelay: '0.1s' }}>é</span>
              <span style={{ animationDelay: '0.2s' }}>c</span>
              <span style={{ animationDelay: '0.3s' }}>i</span>
              <span style={{ animationDelay: '0.4s' }}>s</span>
            </span>
          </a>
          <ul className="nav-links">
            <li><a href="#hero" className={activeSection === 'hero' ? 'active' : ''}>{t('nav.home')}</a></li>
            <li><a href="#features" className={(activeSection === 'features' || activeSection === 'comparison') ? 'active' : ''}>{t('nav.features')}</a></li>
            <li><a href="#story" className={activeSection === 'story' ? 'active' : ''}>{t('nav.howItWorks')}</a></li>
            <li><a href="#pricing" className={activeSection === 'pricing' ? 'active' : ''}>{t('nav.pricing')}</a></li>
            <li><a href="#about" className={activeSection === 'about' ? 'active' : ''}>{t('nav.about')}</a></li>
          </ul>
          <div className="lang-toggle">
            <button className={i18n.language === 'fr' ? 'active' : ''} onClick={() => i18n.changeLanguage('fr')}>FR</button>
            <button className={i18n.language === 'en' ? 'active' : ''} onClick={() => i18n.changeLanguage('en')}>EN</button>
          </div>
          <button 
            className="hamburger" 
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            aria-label="Toggle menu"
          >
            <span></span>
            <span></span>
            <span></span>
          </button>
        </div>
      </nav>

      {/* Mobile Menu */}
      <div className={`mobile-menu ${isMenuOpen ? 'open' : ''}`} id="mobile-menu">
        <a href="#hero" onClick={() => setIsMenuOpen(false)}>{t('nav.home')}</a>
        <a href="#features" onClick={() => setIsMenuOpen(false)}>{t('nav.features')}</a>
        <a href="#story" onClick={() => setIsMenuOpen(false)}>{t('nav.howItWorks')}</a>
        <a href="#pricing" onClick={() => setIsMenuOpen(false)}>{t('nav.pricing')}</a>
        <a href="#about" onClick={() => setIsMenuOpen(false)}>{t('nav.about')}</a>
      </div>

      {/* ============================
           1. HERO — PARALLAX (Présentation)
           ============================ */}
      <section className="hero" id="hero" ref={heroRef}>
        <motion.div className="hero-parallax-bg" style={{ y: heroBgY }}>
          {/* Subtle moving language lines */}
          <div className="hero-lang-lines">
            <div className="lang-line lang-line-left">
              {[1, 2, 3].map((i) => (
                <span key={i} style={{ display: 'inline-flex', gap: '30px' }}>
                  <span>Translation</span><span>•</span>
                  <span>Traduction</span><span>•</span>
                  <span>Traducción</span><span>•</span>
                  <span>Übersetzung</span><span>•</span>
                  <span>Traduzione</span><span>•</span>
                  <span>Overzetting</span><span>•</span>
                  <span>翻訳</span><span>•</span>
                  <span>번역</span><span>•</span>
                  <span>翻译</span><span>•</span>
                  <span>ترجمة</span><span>•</span>
                  <span>Перевод</span><span>•</span>
                </span>
              ))}
            </div>
            <div className="lang-line lang-line-right">
              {[1, 2, 3].map((i) => (
                <span key={i} style={{ display: 'inline-flex', gap: '30px' }}>
                  <span>Documents</span><span>•</span>
                  <span>Actes</span><span>•</span>
                  <span>Certificats</span><span>•</span>
                  <span>Contrats</span><span>•</span>
                  <span>Diplômes</span><span>•</span>
                  <span>Documents</span><span>•</span>
                  <span>書類</span><span>•</span>
                  <span>문서</span><span>•</span>
                  <span>文档</span><span>•</span>
                  <span>عقود</span><span>•</span>
                  <span>Справки</span><span>•</span>
                </span>
              ))}
            </div>
            <div className="lang-line lang-line-left">
              {[1, 2, 3].map((i) => (
                <span key={i} style={{ display: 'inline-flex', gap: '30px' }}>
                  <span>Precision</span><span>•</span>
                  <span>Précision</span><span>•</span>
                  <span>Precisión</span><span>•</span>
                  <span>Präzision</span><span>•</span>
                  <span>Precisione</span><span>•</span>
                  <span>Precisie</span><span>•</span>
                  <span>精度</span><span>•</span>
                  <span>정밀도</span><span>•</span>
                  <span>精确</span><span>•</span>
                  <span>دقة</span><span>•</span>
                  <span>Точность</span><span>•</span>
                </span>
              ))}
            </div>
            <div className="lang-line lang-line-right">
              {[1, 2, 3].map((i) => (
                <span key={i} style={{ display: 'inline-flex', gap: '30px' }}>
                  <span>AI &amp; Human</span><span>•</span>
                  <span>IA &amp; Humain</span><span>•</span>
                  <span>IA y Humano</span><span>•</span>
                  <span>KI &amp; Mensch</span><span>•</span>
                  <span>IA &amp; Umano</span><span>•</span>
                  <span>AI &amp; Mens</span><span>•</span>
                  <span>AI &amp; 人間</span><span>•</span>
                  <span>AI &amp; 인간</span><span>•</span>
                  <span>AI &amp; 人类</span><span>•</span>
                  <span>ذكاء بشري واصطناعي</span><span>•</span>
                </span>
              ))}
            </div>
          </div>
        </motion.div>
        <motion.div className="hero-grid" style={{ y: heroGridY }}></motion.div>
        <div className="hero-particles">
          <div className="particle" style={{ left: '10%', animationDelay: '0s', animationDuration: '8s' }}></div>
          <div className="particle" style={{ left: '30%', animationDelay: '2s', animationDuration: '12s' }}></div>
          <div className="particle" style={{ left: '50%', animationDelay: '1s', animationDuration: '10s' }}></div>
          <div className="particle" style={{ left: '70%', animationDelay: '4s', animationDuration: '14s' }}></div>
          <div className="particle" style={{ left: '90%', animationDelay: '3s', animationDuration: '9s' }}></div>
        </div>
        <div className="hero-glow"></div>

        <div className="hero-content">
          <div>
            <div className="hero-badge">
              <div className="hero-badge-dot"></div>
              {t('hero.badge')}
            </div>
            <h1 className="hero-title" dangerouslySetInnerHTML={{ __html: t('hero.title') }} />
            <p className="hero-subtitle">
              {t('hero.subtitle')}
            </p>
            <div className="hero-actions">
              <a href="#pricing" className="btn-primary">
                {t('hero.btn_discover')}
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path></svg>
              </a>
              <a href="#story" className="btn-outline">{t('hero.btn_start')}</a>
            </div>
            <div className="hero-stats">
              <div>
                <div className="hero-stat-num">99%</div>
                <div className="hero-stat-label">{t('hero.stat_precision')}</div>
              </div>
              <div>
                <div className="hero-stat-num">24/7</div>
                <div className="hero-stat-label">Disponibilité</div>
              </div>
              <div>
                <div className="hero-stat-num">50+</div>
                <div className="hero-stat-label">Langues</div>
              </div>
            </div>
          </div>

          <div className="hero-visual">
            {/* Slide 1: Document Mockup */}
            <div className="doc-mockup carousel-slide-1">
              <div className="doc-card">
                <div className="doc-header">
                  <div className="doc-dot red"></div>
                  <div className="doc-dot yellow"></div>
                  <div className="doc-dot green"></div>
                  <div className="doc-filename">document_original.docx</div>
                </div>
                <div className="doc-body">
                  <div className="doc-panel">
                    <div className="doc-panel-label">Source</div>
                    <canvas id="pdf-canvas-hero-source" style={{ width: '100%', height: 'auto', display: 'block' }} />
                  </div>
                  <div className="doc-arrow">→</div>
                  <div className="doc-panel">
                    <div className="doc-panel-label right">Traduction</div>
                    <canvas id="pdf-canvas-hero-translated" style={{ width: '100%', height: 'auto', display: 'block' }} />
                  </div>
                </div>
                <div className="doc-progress">
                  <div className="doc-progress-bar"></div>
                </div>
                <div className="doc-badge-formats">
                  <span className="fmt-badge">DOCX</span>
                  <span className="fmt-badge highlighted">PDF</span>
                  <span className="fmt-badge">XLSX</span>
                </div>
              </div>
              
              <div className="floating-label tl">
                <div className="fl-icon blue">A</div>
                <div className="fl-text">
                  <strong>Traduction IA</strong>
                  <span>Optimisée</span>
                </div>
              </div>
              
              <div className="floating-label br">
                <div className="fl-icon gold">✓</div>
                <div className="fl-text">
                  <strong>Relecture Humaine</strong>
                  <span>Certifiée</span>
                </div>
              </div>
            </div>

            {/* Slide 2: Mascot Mockup */}
            <div className="mascot-slide carousel-slide-2">
              <div style={{ backgroundColor: 'white', padding: '40px', borderRadius: '20px', boxShadow: 'var(--shadow-2xl)', border: '1px solid var(--gray-100)', width: '100%', maxWidth: '560px', minHeight: '420px', textAlign: 'center', position: 'relative', display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center' }}>
                <img src={mascot} alt="Mascotte Précis" style={{ width: '180px', height: 'auto', marginBottom: '20px' }} />
                <div style={{ fontSize: '12px', color: 'var(--blue)', fontWeight: '700', textTransform: 'uppercase', letterSpacing: '0.15em' }}>Intelligence Artificielle</div>
                <div style={{ fontSize: '20px', color: 'var(--navy)', fontWeight: '700', marginTop: '5px' }}>L'intelligence au service du sens</div>
                <p style={{ fontSize: '14px', color: 'var(--gray-500)', marginTop: '10px', lineHeight: '1.6', maxWidth: '400px' }}>Une compréhension contextuelle profonde qui surpasse les traducteurs classiques.</p>
                
                {/* Floating Labels to fill space and match doc mockup layout */}
                <div className="floating-label tl">
                  <div className="fl-icon blue" style={{ color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: '700' }}>AI</div>
                  <div className="fl-text">
                    <strong>IA Avancée</strong>
                    <span>Haute Précision</span>
                  </div>
                </div>
                
                <div className="floating-label br">
                  <div className="fl-icon gold" style={{ color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: '700' }}>✓</div>
                  <div className="fl-text">
                    <strong>Sécurité</strong>
                    <span>RGPD Garanti</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ============================
           2. FEATURES SECTION (Description fonctionnalitée)
           ============================ */}
      <section className="features-section" id="features">
        <div className="section-inner">

          {/* Header */}
          <motion.div 
            className="features-header-block"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.1 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          >
            <div className="section-tag">{t('features.tag')}</div>
            <h2 className="section-title" dangerouslySetInnerHTML={{ __html: t('features.title') }} />
            <p className="section-desc">{t('features.desc')}</p>
          </motion.div>

          {/* Feature cards — grille auto-responsive */}
          <div className="feat-grid">

            <motion.div 
              className="feat-card"
              initial={{ opacity: 0, y: 25 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.1 }}
              transition={{ duration: 0.6, delay: 0.05, ease: [0.16, 1, 0.3, 1] }}
            >
              <div className="feat-icon">
                <svg width="22" height="22" fill="none" stroke="var(--blue)" strokeWidth="1.6" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09z"/></svg>
              </div>
              <div className="feat-title">{t('features.card_fidelity_title')}</div>
              <p className="feat-desc">{t('features.card_fidelity_desc')}</p>
            </motion.div>

            <motion.div 
              className="feat-card"
              initial={{ opacity: 0, y: 25 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.1 }}
              transition={{ duration: 0.6, delay: 0.15, ease: [0.16, 1, 0.3, 1] }}
            >
              <div className="feat-icon">
                <svg width="22" height="22" fill="none" stroke="var(--blue)" strokeWidth="1.6" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z"/></svg>
              </div>
              <div className="feat-title">{t('features.card_format_title')}</div>
              <p className="feat-desc">{t('features.card_format_desc')}</p>
            </motion.div>

            <motion.div 
              className="feat-card"
              initial={{ opacity: 0, y: 25 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.1 }}
              transition={{ duration: 0.6, delay: 0.25, ease: [0.16, 1, 0.3, 1] }}
            >
              <div className="feat-icon">
                <svg width="22" height="22" fill="none" stroke="var(--blue)" strokeWidth="1.6" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6A2.25 2.25 0 016 3.75h2.25A2.25 2.25 0 0110.5 6v2.25a2.25 2.25 0 01-2.25 2.25H6a2.25 2.25 0 01-2.25-2.25V6zM3.75 15.75A2.25 2.25 0 016 13.5h2.25a2.25 2.25 0 012.25 2.25v2.25a2.25 2.25 0 01-2.25 2.25H6a2.25 2.25 0 01-2.25-2.25v-2.25zM13.5 6a2.25 2.25 0 012.25-2.25H18A2.25 2.25 0 0120.25 6v2.25A2.25 2.25 0 0118 10.5h-2.25a2.25 2.25 0 01-2.25-2.25V6zM13.5 15.75a2.25 2.25 0 012.25-2.25H18a2.25 2.25 0 012.25 2.25v2.25A2.25 2.25 0 0118 20.25h-2.25a2.25 2.25 0 01-2.25-2.25v-2.25z"/></svg>
              </div>
              <div className="feat-title">Multi-formats &amp; OCR <span className="badge-soon">À venir</span></div>
              <p className="feat-desc">Support natif de tous les formats Office et PDF. La traduction de texte dans les images via OCR arrive bientôt.</p>
            </motion.div>

            <motion.div 
              className="feat-card"
              initial={{ opacity: 0, y: 25 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.1 }}
              transition={{ duration: 0.6, delay: 0.05, ease: [0.16, 1, 0.3, 1] }}
            >
              <div className="feat-icon">
                <svg width="22" height="22" fill="none" stroke="var(--blue)" strokeWidth="1.6" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M16.5 10.5V6.75a4.5 4.5 0 10-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 002.25-2.25v-6.75a2.25 2.25 0 00-2.25-2.25H6.75a2.25 2.25 0 00-2.25 2.25v6.75a2.25 2.25 0 002.25 2.25z"/></svg>
              </div>
              <div className="feat-title">{t('features.card_security_title')}</div>
              <p className="feat-desc">{t('features.card_security_desc')}</p>
            </motion.div>

            <motion.div 
              className="feat-card"
              initial={{ opacity: 0, y: 25 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.1 }}
              transition={{ duration: 0.6, delay: 0.15, ease: [0.16, 1, 0.3, 1] }}
            >
              <div className="feat-icon">
                <svg width="22" height="22" fill="none" stroke="var(--blue)" strokeWidth="1.6" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M15 19.128a9.38 9.38 0 002.625.372 9.337 9.337 0 004.121-.952 4.125 4.125 0 00-7.533-2.493M15 19.128v-.003c0-1.113-.285-2.16-.786-3.07M15 19.128v.106A12.318 12.318 0 018.624 21c-2.331 0-4.512-.645-6.374-1.766l-.001-.109a6.375 6.375 0 0111.964-3.07M12 6.375a3.375 3.375 0 11-6.75 0 3.375 3.375 0 016.75 0zm8.25 2.25a2.625 2.625 0 11-5.25 0 2.625 2.625 0 015.25 0z"/></svg>
              </div>
              <div className="feat-title">{t('features.card_human_title')}</div>
              <p className="feat-desc">{t('features.card_human_desc')}</p>
            </motion.div>

            <motion.div 
              className="feat-card"
              initial={{ opacity: 0, y: 25 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.1 }}
              transition={{ duration: 0.6, delay: 0.25, ease: [0.16, 1, 0.3, 1] }}
            >
              <div className="feat-icon">
                <svg width="22" height="22" fill="none" stroke="var(--blue)" strokeWidth="1.6" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M10.5 21l5.25-11.25L21 21m-9-3h7.5M3 5.621a48.474 48.474 0 016-.371m0 0c1.12 0 2.233.038 3.334.114M9 5.25V3m3.334 2.364C11.176 10.658 7.69 15.08 3 17.502m9.334-12.138c.896.061 1.785.147 2.666.257m-4.589 8.495a18.023 18.023 0 01-3.827-5.802"/></svg>
              </div>
              <div className="feat-title">{t('features.card_languages_title')}</div>
              <p className="feat-desc">{t('features.card_languages_desc')}</p>
            </motion.div>
          </div>

        </div>
      </section>

      {/* ============================
           NEW SECTION: COMPARISON
           ============================ */}
      <section className="comparison-section" id="comparison">
        <div className="section-inner">
          {/* Comparison */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: [0.4, 0, 0.2, 1] }}
            viewport={{ once: true, amount: 0.1 }}
          >
            <div className="comp-section-label">{t('comparison.label')}</div>
            <div className="comp-box">
              <div className="comp-box-header">
                <h3>{t('comparison.title')}</h3>
                <div className="comp-header-badges">
                  <span className="comp-hbadge precis">{t('comparison.header_precis')}</span>
                  <span className="comp-vs">VS</span>
                  <span className="comp-hbadge other">{t('comparison.header_other')}</span>
                </div>
              </div>

              {/* Desktop table */}
              <div className="comp-table-wrap">
                <table className="comp-table">
                  <thead>
                    <tr>
                      <th style={{ width: '34%' }}>{t('comparison.col_criterion')}</th>
                      <th className="th-precis" style={{ width: '33%' }}>{t('comparison.header_precis')}</th>
                      <th className="th-other" style={{ width: '33%' }}>{t('comparison.header_other')}</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>{t('comparison.row_visual')}</td>
                      <td className="td-precis"><div className="comp-val"><span className="comp-chk yes">✓</span><span className="comp-text yes">{t('comparison.row_visual_precis')}</span></div></td>
                      <td className="td-other"><div className="comp-val"><span className="comp-chk no">–</span><span className="comp-text no">{t('comparison.row_visual_other')}</span></div></td>
                    </tr>
                    <tr>
                      <td>{t('comparison.row_meaning')}</td>
                      <td className="td-precis"><div className="comp-val"><span className="comp-chk yes">✓</span><span className="comp-text yes">{t('comparison.row_meaning_precis')}</span></div></td>
                      <td className="td-other"><div className="comp-val"><span className="comp-chk no">–</span><span className="comp-text no">{t('comparison.row_meaning_other')}</span></div></td>
                    </tr>
                    <tr>
                      <td>{t('comparison.row_boxes')}</td>
                      <td className="td-precis"><div className="comp-val"><span className="comp-chk yes">✓</span><span className="comp-text yes">{t('comparison.row_boxes_precis')}</span></div></td>
                      <td className="td-other"><div className="comp-val"><span className="comp-chk no">–</span><span className="comp-text no">{t('comparison.row_boxes_other')}</span></div></td>
                    </tr>
                    <tr>
                      <td>{t('comparison.row_style')}</td>
                      <td className="td-precis"><div className="comp-val"><span className="comp-chk yes">✓</span><span className="comp-text yes">{t('comparison.row_style_precis')}</span></div></td>
                      <td className="td-other"><div className="comp-val"><span className="comp-chk no">–</span><span className="comp-text no">{t('comparison.row_style_other')}</span></div></td>
                    </tr>
                    <tr>
                      <td>{t('comparison.row_ocr')}</td>
                      <td className="td-precis"><div className="comp-val"><span className="comp-chk yes">✓</span><span className="comp-text yes">{t('comparison.row_ocr_precis')}</span></div></td>
                      <td className="td-other"><div className="comp-val"><span className="comp-chk no">–</span><span className="comp-text no">{t('comparison.row_ocr_other')}</span></div></td>
                    </tr>
                    <tr>
                      <td>{t('comparison.row_data')}</td>
                      <td className="td-precis"><div className="comp-val"><span className="comp-chk yes">✓</span><span className="comp-text yes">{t('comparison.row_data_precis')}</span></div></td>
                      <td className="td-other"><div className="comp-val"><span className="comp-chk no">–</span><span className="comp-text no">{t('comparison.row_data_other')}</span></div></td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Mobile cards (visible < 768px) */}
              <div className="comp-mobile-cards">
                <div className="comp-mobile-item">
                  <div className="comp-mobile-criterion">{t('comparison.row_visual')}</div>
                  <div className="comp-mobile-cols">
                    <div className="comp-mobile-col p"><div className="comp-mobile-col-name p">{t('comparison.header_precis')}</div><div className="comp-mobile-col-val p">{t('comparison.row_visual_precis')}</div></div>
                    <div className="comp-mobile-col o"><div className="comp-mobile-col-name o">{t('comparison.header_other')}</div><div className="comp-mobile-col-val o">{t('comparison.row_visual_other')}</div></div>
                  </div>
                </div>
                <div className="comp-mobile-item">
                  <div className="comp-mobile-criterion">{t('comparison.row_meaning')}</div>
                  <div className="comp-mobile-cols">
                    <div className="comp-mobile-col p"><div className="comp-mobile-col-name p">{t('comparison.header_precis')}</div><div className="comp-mobile-col-val p">{t('comparison.row_meaning_precis')}</div></div>
                    <div className="comp-mobile-col o"><div className="comp-mobile-col-name o">{t('comparison.header_other')}</div><div className="comp-mobile-col-val o">{t('comparison.row_meaning_other')}</div></div>
                  </div>
                </div>
                <div className="comp-mobile-item">
                  <div className="comp-mobile-criterion">{t('comparison.row_boxes')}</div>
                  <div className="comp-mobile-cols">
                    <div className="comp-mobile-col p"><div className="comp-mobile-col-name p">{t('comparison.header_precis')}</div><div className="comp-mobile-col-val p">{t('comparison.row_boxes_precis')}</div></div>
                    <div className="comp-mobile-col o"><div className="comp-mobile-col-name o">{t('comparison.header_other')}</div><div className="comp-mobile-col-val o">{t('comparison.row_boxes_other')}</div></div>
                  </div>
                </div>
                <div className="comp-mobile-item">
                  <div className="comp-mobile-criterion">{t('comparison.row_style')}</div>
                  <div className="comp-mobile-cols">
                    <div className="comp-mobile-col p"><div className="comp-mobile-col-name p">{t('comparison.header_precis')}</div><div className="comp-mobile-col-val p">{t('comparison.row_style_precis')}</div></div>
                    <div className="comp-mobile-col o"><div className="comp-mobile-col-name o">{t('comparison.header_other')}</div><div className="comp-mobile-col-val o">{t('comparison.row_style_other')}</div></div>
                  </div>
                </div>
                <div className="comp-mobile-item">
                  <div className="comp-mobile-criterion">{t('comparison.row_ocr')}</div>
                  <div className="comp-mobile-cols">
                    <div className="comp-mobile-col p"><div className="comp-mobile-col-name p">{t('comparison.header_precis')}</div><div className="comp-mobile-col-val p">{t('comparison.row_ocr_precis')}</div></div>
                    <div className="comp-mobile-col o"><div className="comp-mobile-col-name o">{t('comparison.header_other')}</div><div className="comp-mobile-col-val o">{t('comparison.row_ocr_other')}</div></div>
                  </div>
                </div>
                <div className="comp-mobile-item">
                  <div className="comp-mobile-criterion">{t('comparison.row_data')}</div>
                  <div className="comp-mobile-cols">
                    <div className="comp-mobile-col p"><div className="comp-mobile-col-name p">{t('comparison.header_precis')}</div><div className="comp-mobile-col-val p">{t('comparison.row_data_precis')}</div></div>
                    <div className="comp-mobile-col o"><div className="comp-mobile-col-name o">{t('comparison.header_other')}</div><div className="comp-mobile-col-val o">{t('comparison.row_data_other')}</div></div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* ============================
           3. STORYTELLING BAND (Mode de fonctionnement)
           ============================ */}
      <section className="story-band" id="story" ref={storyRef} style={{ position: 'relative', overflow: 'hidden', background: 'linear-gradient(135deg, #fbfaf7 0%, #f6f8fb 100%)', padding: showPreview ? '0' : '40px 0' }}>
        {/* Floating Background Elements */}
        <div style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', pointerEvents: 'none', zIndex: 0 }}>
          <motion.div 
            animate={{ y: [0, 20, 0], rotate: [0, -10, 0] }}
            transition={{ duration: 7, repeat: Infinity, ease: "easeInOut" }}
            style={{ position: 'absolute', top: '20%', right: '10%', opacity: 0.1, color: 'var(--blue)' }}
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" style={{ width: '90px', height: '90px' }}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 21a9.004 9.004 0 008.716-6.747M12 21a9.004 9.004 0 01-8.716-6.747M12 21c2.485 0 4.5-4.03 4.5-9S14.485 3 12 3m0 18c-2.485 0-4.5-4.03-4.5-9S9.515 3 12 3m0 0a8.997 8.997 0 017.843 4.582M12 3a8.997 8.997 0 00-7.843 4.582m15.686 0A11.953 11.953 0 0112 10.5c-2.998 0-5.74-1.1-7.843-2.918m15.686 0A8.959 8.959 0 0121 12c0 .778-.099 1.533-.284 2.253m0 0A17.919 17.919 0 0112 16.5c-3.162 0-6.133-.815-8.716-2.247m0 0A9.015 9.015 0 013 12c0-.778.099-1.533.284-2.253" />
            </svg>
          </motion.div>
          <motion.div 
            animate={{ y: [0, -20, 0], rotate: [0, 15, 0] }}
            transition={{ duration: 9, repeat: Infinity, ease: "easeInOut", delay: 2 }}
            style={{ position: 'absolute', bottom: '15%', left: '10%', opacity: 0.1, color: 'var(--gold)' }}
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" style={{ width: '80px', height: '80px' }}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607zM10.5 7.5v6m3-3h-6" />
            </svg>
          </motion.div>
        </div>

        <div className="section-inner" style={{ position: 'relative', zIndex: 1, maxWidth: '1240px', padding: '0 24px', margin: '0 auto', height: showPreview ? '100%' : 'auto', display: showPreview ? 'flex' : 'block', flexDirection: showPreview ? 'column' : 'unset' }}>
          {!showPreview ? (
            <div className="story-grid">
              <div>
                <span className="section-tag">{t('story.tag')}</span>
                <h2 className="section-title" dangerouslySetInnerHTML={{ __html: t('story.title') }} />
                <p className="section-desc">
                  {t('story.desc')}
                </p>
                
                <div className="story-steps">
                  <div className="story-step">
                    <div className="story-step-line">
                      <div className="story-step-num">01</div>
                      <div className="story-step-connector"></div>
                    </div>
                    <div className="story-step-content">
                      <h3>{t('story.step1_title')}</h3>
                      <p>{t('story.step1_desc')}</p>
                    </div>
                  </div>
                  
                  <div className="story-step">
                    <div className="story-step-line">
                      <div className="story-step-num">02</div>
                      <div className="story-step-connector"></div>
                    </div>
                    <div className="story-step-content">
                      <h3>{t('story.step2_title')}</h3>
                      <p>{t('story.step2_desc')}</p>
                    </div>
                  </div>
                  
                  <div className="story-step">
                    <div className="story-step-line">
                      <div className="story-step-num">03</div>
                      <div className="story-step-connector"></div>
                    </div>
                    <div className="story-step-content">
                      <h3>{t('story.step3_title')}</h3>
                      <p>{t('story.step3_desc')}</p>
                    </div>
                  </div>
                  
                  <div className="story-step">
                    <div className="story-step-line">
                      <div className="story-step-num">04</div>
                    </div>
                    <div className="story-step-content">
                      <h3>{t('story.step4_title')}</h3>
                      <p>{t('story.step4_desc')}</p>
                    </div>
                  </div>
                </div>
              </div>

              <motion.div className="story-visual" style={{ height: '100%', y: storyVisualY }}>
                <div style={{ backgroundColor: 'white', padding: '30px', borderRadius: '16px', boxShadow: 'var(--shadow-lg)', border: '1px solid var(--gray-100)', height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '15px', marginBottom: '20px' }}>
                    <img src={mascot} alt="Mascotte" style={{ width: '50px', height: 'auto', border: '1px solid var(--gray-200)' }} />
                    <h3 style={{ fontSize: '24px', fontWeight: '800', color: 'var(--navy)', marginBottom: 0 }}>{t('story.visual_title')}</h3>
                  </div>
                  
{/* File Upload */}
                   <div 
                     style={{ border: '2px dashed rgba(37, 99, 235, 0.3)', backgroundColor: 'rgba(37, 99, 235, 0.02)', borderRadius: '12px', padding: '30px 20px', textAlign: 'center', marginBottom: '20px', cursor: 'pointer', transition: 'all 0.2s ease' }}
                     onClick={() => fileInputRef.current?.click()}
                     onDragOver={(e) => { e.preventDefault(); e.currentTarget.style.backgroundColor = 'rgba(37, 99, 235, 0.05)'; e.currentTarget.style.borderColor = 'var(--blue)'; }}
                     onDragLeave={(e) => { e.preventDefault(); e.currentTarget.style.backgroundColor = 'rgba(37, 99, 235, 0.02)'; e.currentTarget.style.borderColor = 'rgba(37, 99, 235, 0.3)'; }}
                     onDrop={(e) => { e.preventDefault(); e.currentTarget.style.backgroundColor = 'rgba(37, 99, 235, 0.02)'; e.currentTarget.style.borderColor = 'rgba(37, 99, 235, 0.3)'; const file = e.dataTransfer.files[0]; if (file) { setSelectedFile(file); } }}
                   >
                     <input
                       ref={fileInputRef}
                       type="file"
                       accept=".txt,.pdf,.docx"
                       style={{ display: 'none' }}
                       onChange={(e) => { const file = e.target.files?.[0]; if (file) { setSelectedFile(file); } }}
                     />
                     <div style={{ color: 'var(--blue)', marginBottom: '10px' }}>
                       <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" style={{ width: '36px', height: '36px', margin: '0 auto' }}>
                         <path strokeLinecap="round" strokeLinejoin="round" d="M12 16.5V9.75m0 0l3 3m-3-3l-3 3M6.75 19.5a4.5 4.5 0 01-1.41-8.775 5.25 5.25 0 0110.233-2.33 3 3 0 013.758 3.848A3.752 3.752 0 0118 19.5H6.75z" />
                       </svg>
                     </div>
                     <p style={{ fontSize: '14px', color: 'var(--navy)', fontWeight: '600' }}>{selectedFile ? selectedFile.name : t('story.drop_text')}</p>
                     <p style={{ fontSize: '13px', color: 'var(--gray-500)', marginTop: '5px' }} dangerouslySetInnerHTML={{ __html: t('story.browse_text') }} />
                     <p style={{ fontSize: '11px', color: 'var(--gray-400)', marginTop: '10px' }}>{t('story.formats_text')}</p>
                   </div>

                  {/* Languages */}
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '20px' }}>
                    <div>
                      <label style={{ fontSize: '12px', fontWeight: '600', color: 'var(--navy)', display: 'block', marginBottom: '5px' }}>{t('story.source_lang')}</label>
                      <select style={{ width: '100%', padding: '12px 15px', borderRadius: '10px', border: '1px solid var(--gray-300)', fontSize: '14px', appearance: 'none', backgroundColor: '#f1f5f9', backgroundImage: `url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6 9 12 15 18 9'%3e%3c/polyline%3e%3c/svg%3e")`, backgroundRepeat: 'no-repeat', backgroundPosition: 'right 15px center', backgroundSize: '16px', color: 'var(--navy)' }}>
                        <option>{t('story.auto_detect')}</option>
                        <option>{t('story.lang_fr')}</option>
                        <option>{t('story.lang_en')}</option>
                        <option>{t('story.lang_es')}</option>
                      </select>
                    </div>
                    <div>
                      <label style={{ fontSize: '12px', fontWeight: '600', color: 'var(--navy)', display: 'block', marginBottom: '5px' }}>{t('story.target_lang')}</label>
                      <select style={{ width: '100%', padding: '12px 15px', borderRadius: '10px', border: '1px solid var(--gray-300)', fontSize: '14px', appearance: 'none', backgroundColor: '#f1f5f9', backgroundImage: `url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6 9 12 15 18 9'%3e%3c/polyline%3e%3c/svg%3e")`, backgroundRepeat: 'no-repeat', backgroundPosition: 'right 15px center', backgroundSize: '16px', color: 'var(--navy)' }}>
                        <option>{t('story.lang_en')}</option>
                        <option>{t('story.lang_fr')}</option>
                        <option>{t('story.lang_es')}</option>
                      </select>
                    </div>
                  </div>

                  {/* Modes */}
                  <div style={{ marginBottom: '20px' }}>
                    <label style={{ fontSize: '12px', fontWeight: '600', color: 'var(--navy)', display: 'block', marginBottom: '5px' }}>Mode de traduction</label>
                    <select style={{ width: '100%', padding: '12px 15px', borderRadius: '10px', border: '1px solid var(--gray-300)', fontSize: '14px', appearance: 'none', backgroundColor: '#f1f5f9', backgroundImage: `url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6 9 12 15 18 9'%3e%3c/polyline%3e%3c/svg%3e")`, backgroundRepeat: 'no-repeat', backgroundPosition: 'right 15px center', backgroundSize: '16px', color: 'var(--navy)' }}>
                      <option>Conserver le sens absolument (Recommandé)</option>
                      <option>Traduire sur une longueur proportionnelle</option>
                      <option>Style Formel</option>
                      <option>Style Décontracté</option>
                    </select>
                  </div>

{/* Button */}
                    <button 
                      onClick={async () => {
                        if (selectedFile) {
                          try {
                            const result = await translateFile(selectedFile, targetLang);
                            setTranslatedBlob(result.blob);
                            setTranslatedFilename(result.filename);
                            setShowPreview(true);
                          } catch (err) {
                            // Error handled by hook
                          }
                        } else {
                          setShowPreview(true);
                        }
                      }} 
                      disabled={isTranslating || !selectedFile}
                     style={{ 
                       width: '100%', 
                       padding: '12px', 
                       backgroundColor: isTranslating || !selectedFile ? 'var(--gray-300)' : 'var(--blue)', 
                       color: 'white', 
                       borderRadius: '8px', 
                       fontWeight: '600', 
                       border: 'none', 
                       cursor: isTranslating || !selectedFile ? 'not-allowed' : 'pointer', 
                       transition: 'background 0.2s' 
                     }}
                   >
                     {isTranslating ? 'Traduction...' : 'Traduire'}
                   </button>
                   {translateError && <div style={{ color: 'var(--gray-500)', fontSize: '13px', marginTop: '8px' }}>{translateError}</div>}
                </div>
              </motion.div>
            </div>
          ) : (
                <div className="content-viewer w-full flex-1 pr-[8px]">
                  <h2 className="sr-only">Interface de prévisualisation de traduction de document côte-à-côte</h2>

                  <div className="app">



                    <div className="body">
                      <div className="sidebar">
                        <div className="thumb">
                          <div className="thumb-frame">
                            <div className="tl" style={{ width: '55%', height: '3px', marginBottom: '1px' }}></div>
                            <div className="tl muted" style={{ width: '42%' }}></div>
                            <div className="tl accent" style={{ width: '100%', margin: '3px 0' }}></div>
                            <div className="tl" style={{ width: '88%' }}></div>
                            <div className="tl muted" style={{ width: '72%' }}></div>
                            <div className="tl muted" style={{ width: '80%' }}></div>
                            <div className="tl muted" style={{ width: '65%' }}></div>
                            <div className="tl accent" style={{ width: '100%', margin: '3px 0' }}></div>
                            <div className="tl" style={{ width: '78%' }}></div>
                            <div className="tl muted" style={{ width: '55%' }}></div>
                            <div className="tl muted" style={{ width: '70%' }}></div>
                            <div className="tl muted" style={{ width: '62%' }}></div>
                            <div className="tl accent" style={{ width: '100%', margin: '3px 0' }}></div>
                            <div className="tl" style={{ width: '80%' }}></div>
                            <div className="tl muted" style={{ width: '60%' }}></div>
                            <div className="tl muted" style={{ width: '75%' }}></div>
                          </div>
                          <div className="thumb-num">1</div>
                        </div>
                      </div>

                      <div className="main">
                        <div className="docbar">
                          <button onClick={() => { setShowPreview(false); setTranslatedBlob(null); setTranslatedFilename(''); }} className="tb-btn ghost" aria-label="Retour" title="Retour" style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                            <i className="ti ti-arrow-left" style={{ fontSize: '14px' }} aria-hidden="true"></i>
                            <span>Retour</span>
                          </button>
                          <button onClick={() => setZoom(zoom === 2.0 ? 1.0 : zoom + 0.5)} className="tb-btn ghost" aria-label="Zoom" title="Zoom" style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                            <i className="ti ti-zoom-in" style={{ fontSize: '14px' }} aria-hidden="true"></i>
                            <span>{Math.round(zoom * 100)}%</span>
                          </button>
                          <div className="spacer"></div>
                          {translatedBlob ? (
                            <button 
                              onClick={() => {
                                const url = URL.createObjectURL(translatedBlob);
                                const a = document.createElement('a');
                                a.href = url;
                                a.download = translatedFilename;
                                document.body.appendChild(a);
                                a.click();
                                URL.revokeObjectURL(url);
                                document.body.removeChild(a);
                              }}
                              className="tb-btn ghost"
                              aria-label="Télécharger la traduction"
                              title="Télécharger la traduction"
                              style={{ display: 'flex', alignItems: 'center', gap: '6px' }}
                            >
                              <i className="ti ti-download" style={{ fontSize: '14px' }} aria-hidden="true"></i>
                            </button>
                          ) : (
                            <a href="/CV_Mbowou_Ibrahim_Pigier_TRADUIT.pdf" download className="tb-btn ghost" aria-label="Télécharger la traduction" title="Télécharger la traduction" style={{ display: 'flex', alignItems: 'center', gap: '6px', textDecoration: 'none' }}>
                              <i className="ti ti-download" style={{ fontSize: '14px' }} aria-hidden="true"></i>
                            </a>
                          )}
                        </div>

                        <div className="scroll" id="scroll" style={{ alignItems: 'flex-start' }}>

                            <div className="cv-wrap" style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', position: 'relative' }}>
                              <span className="cv-lang-badge fr">FR — Original</span>
                              <div className="cv" id="cv-fr" style={{ overflow: 'auto' }}>
                                <canvas id="pdf-canvas-original" style={{ display: 'block', height: 'auto', margin: '0 auto' }} />
                              </div>
                            </div>
                            
                            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative', width: '20px', flexShrink: 0 }}>
                              <div style={{ width: '1px', height: '100%', background: 'var(--color-border-tertiary)' }}></div>
                            </div>

                            <div className="cv-wrap" style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', position: 'relative' }}>
                              <span className="cv-lang-badge en" style={{ background: '#f0fdf4', color: '#15803d' }}>EN — Traduction</span>
                              <div 
                                className="cv trial-viewer" 
                                id="cv-en" 
                                style={{ overflow: 'auto', position: 'relative' }}
                                onMouseMove={(e) => {
                                  if (!isTrialMode) return;
                                  const rect = e.currentTarget.getBoundingClientRect();
                                  const x = e.clientX - rect.left;
                                  const y = e.clientY - rect.top;
                                  const revealer = document.getElementById('revealer-cursor');
                                  if (revealer) {
                                    const size = 5 * 37.8; // 5cm to pixels (approx)
                                    revealer.style.left = `${x - size/2}px`;
                                    revealer.style.top = `${y - size/2}px`;
                                  }
                                }}
                              >
                                <canvas 
                                  id="pdf-canvas-translated" 
                                  style={{ 
                                    display: 'block', 
                                    height: 'auto', 
                                    margin: '0 auto',
                                    filter: isTrialMode ? 'blur(4px) grayscale(70%)' : 'none'
                                  }} 
                                />
                                {isTrialMode && (
                                  <>
                                    <div 
                                      id="revealer-cursor"
                                      className="revealer-cursor"
                                      style={{
                                        position: 'absolute',
                                        width: '5cm',
                                        height: '5cm',
                                        borderRadius: '8px',
                                        border: '2px solid var(--blue)',
                                        boxShadow: '0 0 20px rgba(37, 99, 235, 0.3)',
                                        pointerEvents: 'none',
                                        overflow: 'hidden',
                                        left: '0px',
                                        top: '0px',
                                        zIndex: 10,
                                        background: 'rgba(255,255,255,0.85)'
                                      }}
                                    />
                                    <div style={{
                                      position: 'absolute',
                                      bottom: '10px',
                                      left: '50%',
                                      transform: 'translateX(-50%)',
                                      background: 'rgba(13, 27, 62, 0.9)',
                                      color: 'white',
                                      padding: '8px 16px',
                                      borderRadius: '6px',
                                      fontSize: '12px',
                                      whiteSpace: 'nowrap'
                                    }}>
                                      Version d'essai - Passez le curseur sur le document pour l'apercevoir en clair
                                    </div>
                                  </>
                                )}
                              </div>
                            </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
          )}
        </div>
      </section>

      {/* ============================
           4. PRICING (Tarification)
           ============================ */}
      <section className="pricing-section" id="pricing">
        <div className="section-inner">
          <div className="pricing-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '20px', marginBottom: '40px' }}>
            <div>
              <span className="section-tag">{t('pricing.tag')}</span>
              <h2 className="section-title" style={{ marginBottom: 0 }} dangerouslySetInnerHTML={{ __html: t('pricing.title') }} />
            </div>
            
            {/* Modern Pills Toggle */}
            <div style={{ display: 'flex', background: 'var(--gray-100)', borderRadius: '30px', padding: '4px', position: 'relative', cursor: 'pointer', minWidth: '250px' }}>
              <div 
                style={{ 
                  position: 'absolute', 
                  top: '4px', 
                  left: isAnnual ? '50%' : '4px',
                  width: 'calc(50% - 4px)', 
                  height: 'calc(100% - 8px)', 
                  background: 'white', 
                  borderRadius: '25px', 
                  boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
                  transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                  zIndex: 1
                }}
              />
              <div 
                onClick={() => setIsAnnual(false)}
                style={{ 
                  flex: 1, 
                  textAlign: 'center', 
                  padding: '8px 16px', 
                  fontSize: '13px', 
                  fontWeight: !isAnnual ? '600' : '500', 
                  color: !isAnnual ? 'var(--navy)' : 'var(--gray-500)',
                  position: 'relative',
                  zIndex: 2,
                  transition: 'color 0.3s',
                  whiteSpace: 'nowrap'
                }}
              >
                {t('pricing.monthly')}
              </div>
              <div 
                onClick={() => setIsAnnual(true)}
                style={{ 
                  flex: 1, 
                  textAlign: 'center', 
                  padding: '8px 16px', 
                  fontSize: '13px', 
                  fontWeight: isAnnual ? '600' : '500', 
                  color: isAnnual ? 'var(--navy)' : 'var(--gray-500)',
                  position: 'relative',
                  zIndex: 2,
                  transition: 'color 0.3s',
                  whiteSpace: 'nowrap'
                }}
              >
                {t('pricing.annual')} <span style={{ color: '#1a4dc7', fontSize: '11px', fontWeight: '700' }}>{t('pricing.discount')}</span>
              </div>
            </div>
          </div>

          <div className="pricing-grid">
            {/* Card 1: Besoins Ponctuels */}
            <div className="pricing-card">
              <div className="pricing-plan">{t('pricing.plan_one_off')}</div>
              <div className="pricing-price">{t('pricing.price_carte')}</div>
              <p className="pricing-desc">{t('pricing.desc_one_off')}</p>
              <div className="pricing-divider"></div>
              <ul className="pricing-features">
                <li><span style={{ fontWeight: '600', color: 'var(--navy)' }}>{t('pricing.per_word')}</span> 0,02 € / mot</li>
                <li><span style={{ fontWeight: '600', color: 'var(--navy)' }}>{t('pricing.word_file')}</span> 1,50 €</li>
                <li><span style={{ fontWeight: '600', color: 'var(--navy)' }}>{t('pricing.ppt_file')}</span> 2,50 €</li>
                <li><span style={{ fontWeight: '600', color: 'var(--navy)' }}>{t('pricing.pdf_file')}</span> 3,00 €</li>
              </ul>
              <a href="#" className="btn-pricing">{t('pricing.btn_start')}</a>
            </div>

            {/* Plan 2 */}
            <div className="pricing-card">
              <div className="pricing-plan">{isAnnual ? t('pricing.plan_starter_annual') : t('pricing.plan_free')}</div>
              <div className="pricing-price">
                {isAnnual ? t('pricing.price_starter_annual') : t('pricing.price_free')} <sup>€</sup><span className="period">{t('pricing.period_month')}</span>
              </div>
              <p className="pricing-desc">{isAnnual ? t('pricing.desc_starter_annual') : t('pricing.desc_free')}</p>
              <div className="pricing-divider"></div>
              <ul className="pricing-features">
                <li>{isAnnual ? t('pricing.starter_words') : t('pricing.free_words')}</li>
                <li>{isAnnual ? t('pricing.download_included') : t('pricing.preview_only')}</li>
                <li>{isAnnual ? t('pricing.support_standard') : t('pricing.no_download')}</li>
                {isAnnual && <li style={{ color: 'var(--blue)', fontWeight: 'bold' }}>{t('pricing.discount_included')}</li>}
              </ul>
              <a href="#" className="btn-pricing">{t('pricing.btn_choose')}</a>
            </div>

            {/* Plan 3 */}
            <div className="pricing-card popular">
              <div className="popular-badge">{t('pricing.recommended')}</div>
              <div className="pricing-plan">{isAnnual ? t('pricing.plan_pro_annual') : t('pricing.plan_pro_monthly')}</div>
              <div className="pricing-price">
                {isAnnual ? t('pricing.price_pro_annual') : t('pricing.price_pro_monthly')} <sup>€</sup><span className="period">{t('pricing.period_month')}</span>
              </div>
              <p className="pricing-desc">{t('pricing.desc_pro')}</p>
              <div className="pricing-divider"></div>
              <ul className="pricing-features">
                <li>{t('pricing.pro_words')}</li>
                <li>{t('pricing.support_priority')}</li>
                <li>{t('pricing.trial_text')}</li>
                {isAnnual && <li style={{ color: 'var(--blue)', fontWeight: 'bold' }}>{t('pricing.save_text')}</li>}
              </ul>
              <a href="#" className="btn-pricing">{t('pricing.btn_choose_pro')}</a>
            </div>

            {/* Plan 4 */}
            <div className="pricing-card">
              <div className="pricing-plan">{isAnnual ? t('pricing.plan_business') : t('pricing.plan_starter_monthly')}</div>
              <div className="pricing-price">
                {isAnnual ? t('pricing.price_business') : t('pricing.price_starter_monthly')} <sup>€</sup><span className="period">{isAnnual ? t('pricing.period_year') : t('pricing.period_month')}</span>
              </div>
              <p className="pricing-desc">{isAnnual ? t('pricing.desc_business') : t('pricing.desc_starter_monthly')}</p>
              <div className="pricing-divider"></div>
              <ul className="pricing-features">
                <li>{isAnnual ? t('pricing.business_words') : t('pricing.starter_monthly_words')}</li>
                <li>{isAnnual ? t('pricing.api_access') : t('pricing.support_standard')}</li>
                {isAnnual ? <li>{t('pricing.sla_guaranteed')}</li> : <li>{t('pricing.excess_rate')}</li>}
              </ul>
              <a href="#" className="btn-pricing">{t('pricing.btn_choose')}</a>
            </div>
          </div>
        </div>
      </section>

      {/* ============================
           5. ABOUT SECTION (Présentation Trigenys) + FOOTER
           ============================ */}
      <section className="about-section" id="about" ref={aboutRef}>
        <div className="section-inner" style={{ flex: 1, display: 'flex', alignItems: 'center', width: '100%' }}>
          <div className="story-grid" style={{ width: '100%' }}>
            <div>
              <span className="section-tag">{t('about.tag')}</span>
              <h2 className="section-title" dangerouslySetInnerHTML={{ __html: t('about.title') }} />
              <p className="section-desc">
                {t('about.desc')}
              </p>
              <p className="text-gray-500 mt-4 text-sm max-w-lg" style={{ lineHeight: '1.7', marginTop: '16px' }}>
                {t('about.mission')}
              </p>
              <div className="about-values flex gap-6" style={{ marginTop: '24px', display: 'flex', gap: '24px' }}>
                <div>
                  <div className="font-bold text-navy" style={{ color: 'var(--navy)', fontWeight: '700' }}>{t('about.val_innovation')}</div>
                  <div className="text-xs text-gray-500">{t('about.val_innovation_desc')}</div>
                </div>
                <div>
                  <div className="font-bold text-navy" style={{ color: 'var(--navy)', fontWeight: '700' }}>{t('about.val_quality')}</div>
                  <div className="text-xs text-gray-500">{t('about.val_quality_desc')}</div>
                </div>
                <div>
                  <div className="font-bold text-navy" style={{ color: 'var(--navy)', fontWeight: '700' }}>{t('about.val_security')}</div>
                  <div className="text-xs text-gray-500">{t('about.val_security_desc')}</div>
                </div>
              </div>
            </div>
            <motion.div className="story-visual" style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', y: aboutVisualY }}>
              <div style={{ backgroundColor: 'white', padding: '20px', borderRadius: '20px', boxShadow: 'var(--shadow-lg)', border: '1px solid var(--gray-100)', display: 'flex', justifyContent: 'center', alignItems: 'center', maxWidth: '360px' }}>
                <img src={mascot} alt="Mascotte Précis" style={{ width: '100%', height: 'auto', borderRadius: '12px' }} />
              </div>
            </motion.div>
          </div>
        </div>

        {/* Integrated Footer */}
        <div style={{ borderTop: '1px solid var(--gray-200)', paddingTop: '20px', width: '100%', maxWidth: '1240px', margin: '0 auto' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '0.75rem', color: 'var(--gray-500)' }}>
            <p>{t('footer.rights')}</p>
            <div style={{ display: 'flex', gap: '16px' }}>
              <a href="#" style={{ color: 'inherit' }}>{t('footer.legal')}</a>
              <a href="#" style={{ color: 'inherit' }}>{t('footer.terms')}</a>
              <a href="#" style={{ color: 'inherit' }}>{t('footer.privacy')}</a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
